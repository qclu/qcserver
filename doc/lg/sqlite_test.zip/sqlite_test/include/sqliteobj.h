#ifndef SQLITEOBJ_HEADER
#define SQLITEOBJ_HEADER

#include <stdlib.h>
#include <stdio.h>
extern "C"
{
#include "sqlite3.h"
};

typedef enum{
	RES_OK = 0,
	ERR_ARGINVALID = -1,
}RES_CODE;

typedef int (*sqlite_callback)(void*,int,char**, char**);

typedef struct SqlExecContext
{
	char sql_str[1024];
	sqlite_callback cbk;
	void* res_buf;
	int buf_len;		//in bytes
	int res_cnt;
}sql_extc_context_t;

typedef struct SqlDb 
{
	sqlite3* dbHandle;
}db_obj_t;

db_obj_t* OpenDb(const char* dbFile)
{
	int err_no = 0;
	db_obj_t* dbObj = (db_obj_t*)malloc(sizeof(db_obj_t));
	err_no = sqlite3_open_v2(dbFile, &dbObj->dbHandle, SQLITE_OPEN_READWRITE, NULL);
	if (err_no != SQLITE_OK)
	{
		printf("Error: Failed to open db file '%s', error: %d.\n", dbFile, err_no);
		free(dbObj);
		return NULL;
	}
	return dbObj;
}

int CloseDb(db_obj_t* dbObj)
{
	if (!dbObj)
	{
		printf("Error: Invalid parameter for 'CloseDb', Database object is null.\n");
		return ERR_ARGINVALID;
	}
	int err_no = sqlite3_close(dbObj->dbHandle);
	if (err_no)
	{
		printf("Error: Failed to close db file, err: %d.\n", err_no);
		return err_no;
	}
	free(dbObj);
	return RES_OK;
}

int PerformDbOp(db_obj_t* dbObj, sql_extc_context_t* sql_ctx)
{
	char* errMsg = NULL;
	int err_no = RES_OK;
	err_no = sqlite3_exec(dbObj->dbHandle, sql_ctx->sql_str, sql_ctx->cbk, sql_ctx, &errMsg);
	if (err_no)
	{
		printf("Error: Failed to exec sql[%s], err: %s.", sql_ctx->sql_str, errMsg);
	}
	return err_no;
}

#endif