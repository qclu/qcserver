#include "sqliteobj.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct User
{
	char name[256];
	int age;
}user_t;

int UserGetCallBack(void* args, int col_cnt,char** col_vals, char** col_names)
{
	sql_extc_context_t* sql_ctx = (sql_extc_context_t*)args;
	if (sql_ctx->res_cnt >= sql_ctx->buf_len / sizeof(user_t))
	{
		printf("Error: res buffer is insufficient when exec sql '%s'.", sql_ctx->sql_str);
		return -1;
	}
	user_t* cur_user = (user_t*)((char*)sql_ctx->res_buf + sql_ctx->res_cnt * sizeof(user_t));
	strcpy(cur_user->name, col_vals[1]);
	cur_user->age = atoi(col_vals[2]);
	sql_ctx->res_cnt++;
	return 0;
}


int UserGetCntCallBack(void* args, int col_cnt,char** col_vals, char** col_names)
{
	sql_extc_context_t* sql_ctx = (sql_extc_context_t*)args;
	int* user_cnt = (int*)(sql_ctx->res_buf);
	*user_cnt = atoi(col_vals[0]);
	sql_ctx->res_cnt++;
	return 0;
}

int main()
{
	db_obj_t* dbObj = OpenDb("./test.db");
	if (!dbObj)
	{
		printf("Error: Failed to open 'test.db'.");
		return -1;
	}
	sql_extc_context_t sql_ctx;
	memset(&sql_ctx, 0, sizeof(sql_extc_context_t));
	int res_len = _snprintf(sql_ctx.sql_str, 1024, "insert into user(name, age) values('%s', %d);", "Qichao", 20);
	if (res_len >= 1024)
	{
		printf("Warning: Sql to exec is more than 1024 bytes.");
		return -1;
	}
	sql_ctx.sql_str[res_len] = 0;
	sql_ctx.buf_len = 0;
	sql_ctx.cbk = 0;
	sql_ctx.res_buf = 0;
	sql_ctx.res_cnt = 0;
	int res = 0;
	res = PerformDbOp(dbObj, &sql_ctx);
	if (res)
	{
		return res;
	}

	//get user count
	res_len = _snprintf(sql_ctx.sql_str, 1024, "select count(*) from user;");
	if (res_len >= 1024 || res_len <= 0)
	{
		printf("Warning: Sql to exec is more than 1024 bytes.");
		return -1;
	}
	int user_cnt = 0;
	sql_ctx.sql_str[res_len] = 0;
	sql_ctx.buf_len = sizeof(int);
	sql_ctx.cbk = UserGetCntCallBack;
	sql_ctx.res_buf = &user_cnt;
	sql_ctx.res_cnt = 0;
	res = PerformDbOp(dbObj, &sql_ctx);
	if (res)
	{
		return res;
	}
	printf("Info: Total %d user in database.\n", user_cnt);

	user_t* users = (user_t*)malloc(sizeof(user_t) * user_cnt);
	res_len = _snprintf(sql_ctx.sql_str, 1024, "select * from user;");
	if (res_len >= 1024 || res_len <= 0)
	{
		printf("Warning: Sql to exec is more than 1024 bytes.");
		return -1;
	}
	sql_ctx.sql_str[res_len] = 0;
	sql_ctx.buf_len = sizeof(user_t) * user_cnt;
	sql_ctx.cbk = UserGetCallBack;
	sql_ctx.res_buf = users;
	sql_ctx.res_cnt = 0;
	res = PerformDbOp(dbObj, &sql_ctx);
	if (res)
	{
		return res;
	}
	printf("Users info: \n");
	for (int i = 0; i < user_cnt; i++)
	{
		printf("id: %d\tname: %s\tage: %d\n", i, users[i].name, users[i].age);
	}
	free(users);

	res = CloseDb(dbObj);
	system("PAUSE");
	return res;
}