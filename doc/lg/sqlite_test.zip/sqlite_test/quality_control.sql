
create table if not exists qc_users (
	ID integer primary key autoincrement not null,
	name varchar(256) not null,
	passwd varchar(128) not null,
	auth integer(8) not null default 0,
	lastlogin varchar(128) not null,
	createtime time not null);
	
create table if not exists qc_instrument_dev (
	ID integer primary key autoincrement not null,
	name varchar(256) unique not null,
	model varchar(256) unique not null,
	produce_time date not null,
	methodology varchar(256) not null,
	hw_version varchar(256) not null,
	sw_version varchar(256) not null,
	log_levle int not null,
	log_annotation varchar(512),
	annotation varchar(512));